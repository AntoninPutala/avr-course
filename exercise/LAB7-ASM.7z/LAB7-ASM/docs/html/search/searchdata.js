var indexSectionsWithContent =
{
  0: "almtu",
  1: "tu",
  2: "lmu",
  3: "atu"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Modules"
};

