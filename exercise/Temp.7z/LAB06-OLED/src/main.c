// https://github.com/Sylaina/oled-display

#include <oled.h>
#include <avr/io.h>         // AVR device-specific IO definitions
#include <avr/interrupt.h>  // Interrupts standard C library for AVR-GCC
#include <twi.h>            // I2C/TWI library for AVR-GCC
#include <stdlib.h>         // C library. Needed for number conversions

int main(void)
{
    char string[2];  // For converting numbers by itoa()
    uint8_t i = 0;

    twi_init();

    oled_init(OLED_DISP_ON);
    oled_clrscr();
    //oled_invert(YES);

    oled_charMode(NORMALSIZE);
    oled_puts("Scanning I2C...");

    oled_gotoxy(0, 1);

    for (uint8_t sla = 8; sla < 120; sla++)
    {
        if (twi_test_address(sla) == 0)  // If ACK from Slave
        {
            oled_puts("0x");
            itoa(sla, string, 16);
            oled_puts(string);
            i++;
            oled_gotoxy(0, i+1);
            
        }
    }

    oled_charMode(NORMALSIZE);

    // oled_gotoxy(x, y)
    //oled_gotoxy(0, 1);
    //oled_puts("128x64, SH1106");

    // oled_drawLine(x1, y1, x2, y2, color)
    oled_drawLine(0, 25, 120, 25, WHITE);

    //oled_gotoxy(0, 4);
    //oled_puts("AVR course, Brno");

    // Copy buffer to display RAM
    //
    oled_display();

    while (1) {
        ;
    }

    return 0;
}