
#include <avr/io.h>     // include names of registers, project know right type, include registers of other MCUs
#include <util/delay.h> // include _delay_ms, _delay_us
#include <gpio.h>       // my own library
#include <stdint.h>

#define LED_GREEN PB5   // LED_GREEN will be replaced by PB5
#define LED_RED PB1     // LED_GREEN will be replaced by PB1
#define BUTTON PB0     // LED_GREEN will be replaced by PB5
#define WAIT 1000

int main(void)
{
    uint8_t button_state;
    // Pin PB5 set as output.
    // DDRB |= (1 << LED_GREEN);
    GPIO_mode_output(&DDRB, LED_GREEN);
    GPIO_mode_output(&DDRB, LED_RED);

    GPIO_mode_input_pullup(&DDRB, BUTTON);


    GPIO_write_low(&PORTB, LED_GREEN);
    GPIO_write_high(&PORTB, LED_RED);
    // Set output PB5 to low, default value, i think it is natural use non-active state as default value
    // PORTB &= ~(1 << LED_GREEN);
    
    // Forever loop  

    while (1)
    {

        button_state = GPIO_read(&PINB, BUTTON);
        /*
        // Set output PB5 to high
        PORTB |= (1 << LED_GREEN);
        // Delay, we have to employ MCU for this time
        _delay_ms(WAIT);
        // Set output PB5 to low
        PORTB &= ~(1 << LED_GREEN);
        // Delay
        _delay_ms(WAIT);
        */

        // Set output PB5 to high
        if (button_state == 1)
        {
            PORTB ^= (1 << LED_GREEN);
            PORTB ^= (1 << LED_RED);
            // Delay
            _delay_ms(WAIT);
        }
        
    }

    return 0;
}
        