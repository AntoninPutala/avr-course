
#include <avr/io.h>
#include <avr/interrupt.h> // contain interrupts
#include <gpio.h>
#include <timer.h>

#define LED_ON_BOARD PB5
#define LED_ON_FIELD PB0

int main()
{
  // Set output leds
  GPIO_mode_output(&DDRB,LED_ON_BOARD);
  GPIO_mode_output(&DDRB,LED_ON_FIELD);
  GPIO_write_low(&PORTB,LED_ON_BOARD);
  GPIO_write_high(&PORTB,LED_ON_FIELD);

  // Set timer1: prescaler + overflow
  TIM1_ovf_262ms();
  TIM1_ovf_enable();

  // Set timer0: prescaler + overflow
  TIM0_ovf_16ms();
  TIM0_ovf_enable();


  // Set global interrupt
  sei(); // last command before forever loop

  // Empty forever loop
  for(;;)
  {

  }

  return 0;
}

ISR(TIMER1_OVF_vect)
{
  GPIO_toggle(&PORTB,LED_ON_BOARD);
}

ISR(TIMER0_OVF_vect)
{
  // Local variables, usable only in body of this function
  static uint8_t n_ovfs = 0; // number of overflow, it will be saved after return, next interrupt will be uploaded

  TCNT0 = 128; // half value of frequency

  n_ovfs++;

  if (n_ovfs >= 6)
  {
    GPIO_toggle(&PORTB,LED_ON_FIELD);
    n_ovfs = 0;
  }
}